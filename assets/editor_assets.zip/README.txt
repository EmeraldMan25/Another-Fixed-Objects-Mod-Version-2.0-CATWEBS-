Thank you for downloading Another Fixed Objects Mod!
--------------------------------------------------------------------------------------------------------------------

Patch the xdelta to the data.win file for the game. I recommend using either Pizza Oven or xdelta UI to patch.

Place the .bank files into the sounds folder in the Steam files for the game. To access those, go into 
Steam -> Pizza Tower -> ⚙️ -> Manage -> Browse Local Files
Then open the folder that says "sound", open "Desktop", and paste the .bank files inside

Place the english.txt file into your lang folder. To do so, follow the same procedure above to get to "Browse Local Files".
After that, find the folder that says "lang" and paste the english.txt inside

--------------------------------------------------------------------------------------------------------------------
Happy Making!