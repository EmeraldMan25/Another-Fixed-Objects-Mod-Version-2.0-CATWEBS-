Thank you for downloading Another Fixed Objects Mod!
--------------------------------------------------------------------------------------------------------------------

You will need to have previously used CYOP or a mod utilizing CYOP before using this mod.

Patch the xdelta to the data.win file for the game. I recommend using either Pizza Oven or xdelta UI to patch.

Place the editor_assets folder into C:/Users/(username)/AppData/Roaming/PizzaTower_GM2

Place the .bank files into the sounds folder in the Steam files for the game

--------------------------------------------------------------------------------------------------------------------
Happy Making!